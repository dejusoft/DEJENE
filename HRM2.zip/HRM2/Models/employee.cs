﻿using System;
using HRM2.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRM2.Models
{
    public class employee
    {
        [Column ]
        public int ID { get; set; }
        [StringLength(20,MinimumLength = 1)]
        [Required]
        [RegularExpression(@"^[A-z]+[a-zA-Z'\s]*$")]
       
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please enter Last name")]
        public string LastName { get; set; }
        public string Gender { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "0:yyyy-MM-dd", ApplyFormatInEditMode = true)]
        public DateTime hireDate { get; set; }
        public string Department_name { get; set; }
       [Salary]
        public string Salary { get; set; }
        public string Address { get; set; }
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        public string jobtitle { get; set; }
        public Department department { get; set; }
        public virtual ICollection<Department> departmentname { get; set; }
        public jobs jobs { get; set; }
       


    }

    internal class SalaryAttribute : ValidationAttribute
    {

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                int salary = Convert.ToInt32(value);
                if (salary < 50000)
                    return new ValidationResult("salary of the user must be greater than  50000");

            }
            return ValidationResult.Success;
        }
    }
        public class hrmcontext : DbContext
        {
            public DbSet<employee> employees { get; set; }
            public DbSet<Department> departments { get; set; }
            public DbSet<Address> addresses { get; set; }
            public DbSet<jobs> job { get; set; }
            public DbSet<account> Accounts { get; set; }
            public DbSet<role> roles { get; set; }


        }

    }
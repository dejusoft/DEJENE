﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace HRM2.Models
{
    public class role
    {
        [Key]
        public int RoleID { get; set; }
        [Required(ErrorMessage = "RoleName is requured.")]
        public string RoleName { get; set; }

       
       
       
    }
}
﻿using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using HRM2.Models;
using static HRM2.Models.SalaryAttribute;

namespace HRM2.Controllers
{
    public class AccountController : Controller
    {
        private hrmcontext db = new hrmcontext();
      

        // GET: Account
        public ActionResult Index()
        {

            return View(db.Accounts.ToList());

        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(account accounts)
        {
            var role = db.roles.ToList();
            string rolename = null;
            role cmsvm = new role
            {
                RoleName = rolename
            };
            //if (ModelState.IsValid)
            //{

            //    db.Accounts.Add(accounts);
            //    db.SaveChanges();

            //    ModelState.Clear();
            //    ViewBag.message = accounts.FirstName + " " + accounts.LastNmae + "successfully registered";
            //}
            return View(cmsvm);
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]

        public ActionResult Login(account user, string ReturnUrl)
        {

            var usr = db.Accounts.Single(u => u.UserName == user.UserName && u.Password == user.Password);
            if (usr != null)
            {
                FormsAuthentication.SetAuthCookie(user.UserName, false);
                Session["UserID"] = usr.UserID.ToString();
                Session["UserNmae"] = usr.UserName.ToString();
                return RedirectToAction("loggedIn");


            }
            else
            {
                ModelState.AddModelError("", "UserName or Password is wroug.");
            }

            return View();

        }
        public ActionResult LoggedIn()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("login");
            }
        }
    }
}